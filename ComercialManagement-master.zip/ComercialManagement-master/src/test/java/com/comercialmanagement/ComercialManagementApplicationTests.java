package com.comercialmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComercialManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
